import React from "react";
import {
  Platform,
  View,
  TouchableOpacity,
} from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import styles from "@/style";

type Props = {
  activeTab: string;
  onTabPress?: (tab: string) => void;
};

const Navigation: React.FC<Props> = ({ activeTab, onTabPress }) => {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const bottomInset = Platform.OS === "ios" ? Math.max(insets.bottom, 10) : 15;

  const handleTabPress = (tab: string) => {
    onTabPress?.(tab);
    if (tab === "home") router.push("/");
    if (tab === "favorites") router.push("/explore");
    if (tab === "messages") router.push("/messages");
    if (tab === "profile") router.push("/profile");
  };

  return (
    <View
      style={[
        styles.navigationContainer,
        {
          paddingBottom: bottomInset,
          height: 72 + bottomInset,
        },
      ]}
    >
      <TouchableOpacity onPress={() => handleTabPress("home")}>
        <Ionicons
          name="home-outline"
          size={24}
          color={activeTab === "home" ? "#FF4D6D" : "#999"}
        />
      </TouchableOpacity>

      <TouchableOpacity onPress={() => handleTabPress("favorites")}>
        <Ionicons
          name="heart-outline"
          size={24}
          color={activeTab === "favorites" ? "#FF4D6D" : "#999"}
        />
      </TouchableOpacity>

      {/* Floating Add Button */}
      <TouchableOpacity
        style={[
          styles.fab,
          { bottom: Platform.OS === "ios" ? bottomInset + 4 : 57 },
        ]}
        onPress={() => handleTabPress("add")}
      >
        <Ionicons name="add" size={28} color="#fff" />
      </TouchableOpacity>

      <TouchableOpacity onPress={() => handleTabPress("messages")}>
        <Ionicons
          name="chatbubble-outline"
          size={24}
          color={activeTab === "messages" ? "#FF4D6D" : "#999"}
        />
      </TouchableOpacity>

      <TouchableOpacity onPress={() => handleTabPress("profile")}>
        <Ionicons
          name="person-outline"
          size={24}
          color={activeTab === "profile" ? "#FF4D6D" : "#999"}
        />
      </TouchableOpacity>
    </View>
  );
};

export default Navigation;
