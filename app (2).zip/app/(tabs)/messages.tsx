import React, { useState } from 'react';
import {
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

type Message = {
  id: string;
  text: string;
  fromMe: boolean;
  time: string;
};

type Conversation = {
  id: string;
  name: string;
  avatar: string;
  online: boolean;
  unread: number;
  time: string;
  lastMessage: string;
  messages: Message[];
};

const SAMPLE_CONVERSATIONS = [
  {
    id: '1',
    name: 'Arielle',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
    online: true,
    unread: 2,
    time: '09:24',
    lastMessage: 'Still thinking about our last chat',
    messages: [
      { id: 'm1', text: 'Hey there', fromMe: false, time: '09:10' },
      { id: 'm2', text: 'Still thinking about our last chat', fromMe: false, time: '09:24' },
    ],
  },
  {
    id: '2',
    name: 'Maya',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=300&q=80',
    online: false,
    unread: 0,
    time: 'Yesterday',
    lastMessage: 'Let me know when you are free',
    messages: [
      { id: 'm3', text: 'Let me know when you are free', fromMe: false, time: 'Yesterday' },
    ],
  },
];

type MessagesListProps = {
  conversations: Conversation[];
  onOpenDM: (conversation: Conversation) => void;
};

type DMScreenProps = {
  conversation: Conversation;
  onBack: () => void;
};

function MessagesList({ conversations, onOpenDM }: MessagesListProps) {
  const isEmpty = conversations.length === 0;

  const renderItem = ({ item }: { item: Conversation }) => (
    <TouchableOpacity style={styles.convoRow} onPress={() => onOpenDM(item)}>
      <View style={styles.avatarWrapper}>
        <Image source={{ uri: item.avatar }} style={styles.avatar} />
        {item.online ? <View style={styles.onlineDot} /> : null}
      </View>

      <View style={styles.convoText}>
        <View style={styles.convoTopRow}>
          <Text style={styles.convoName}>{item.name}</Text>
          <Text style={[styles.convoTime, item.unread > 0 && styles.convoTimeUnread]}>
            {item.time}
          </Text>
        </View>
        <View style={styles.convoBottomRow}>
          <Text
            numberOfLines={1}
            style={[styles.convoLastMsg, item.unread > 0 && styles.convoLastMsgUnread]}>
            {item.lastMessage}
          </Text>
          {item.unread > 0 ? (
            <View style={styles.unreadBadge}>
              <Text style={styles.unreadBadgeText}>{item.unread}</Text>
            </View>
          ) : null}
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.screen}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Messages</Text>
      </View>
      <View style={styles.divider} />

      {isEmpty ? (
        <View style={styles.emptyState}>
          <View style={styles.emptyIcon}>
            <Text style={styles.emptyIconText}>DM</Text>
          </View>
          <Text style={styles.emptyTitle}>You will see your messages here</Text>
          <Text style={styles.emptySubtitle}>
            Once someone matches and messages you, their conversation will appear here.
          </Text>
        </View>
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
        />
      )}
    </SafeAreaView>
  );
}

function DMScreen({ conversation, onBack }: DMScreenProps) {
  const [messages, setMessages] = useState(conversation.messages || []);
  const [input, setInput] = useState('');

  const sendMessage = () => {
    const text = input.trim();
    if (!text) {
      return;
    }

    setMessages((currentMessages: Message[]) => [
      ...currentMessages,
      {
        id: Date.now().toString(),
        text,
        fromMe: true,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setInput('');
  };

  return (
    <SafeAreaView style={styles.screen}>
      <StatusBar barStyle="dark-content" />
      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.dmHeader}>
          <TouchableOpacity onPress={onBack} style={styles.backBtn}>
            <Ionicons name="chevron-back" size={26} color={PINK} />
          </TouchableOpacity>

          <View style={styles.avatarWrapper}>
            <Image source={{ uri: conversation.avatar }} style={styles.avatar} />
            {conversation.online ? <View style={styles.onlineDot} /> : null}
          </View>

          <View style={styles.dmIdentity}>
            <Text style={styles.dmName}>{conversation.name}</Text>
            <Text style={styles.dmStatus}>{conversation.online ? 'Online' : 'Offline'}</Text>
          </View>

          <TouchableOpacity style={styles.heartBtn}>
            <Text style={styles.heartBtnText}>Like</Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={messages}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.messageList}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={[styles.msgRow, item.fromMe ? styles.msgRowMe : styles.msgRowThem]}>
              {!item.fromMe ? (
                <Image source={{ uri: conversation.avatar }} style={styles.msgAvatar} />
              ) : null}
              <View style={item.fromMe ? styles.msgRight : styles.msgLeft}>
                {item.text ? (
                  <View style={[styles.bubble, item.fromMe ? styles.bubbleMe : styles.bubbleThem]}>
                    <Text style={[styles.bubbleText, item.fromMe && styles.bubbleTextMe]}>
                      {item.text}
                    </Text>
                  </View>
                ) : null}
                <Text style={styles.msgTime}>{item.time}</Text>
              </View>
            </View>
          )}
        />

        <View style={styles.inputBar}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Type a message..."
            placeholderTextColor="#9ca3af"
            style={styles.textInput}
            multiline
            onSubmitEditing={sendMessage}
            returnKeyType="send"
          />

          <TouchableOpacity
            onPress={sendMessage}
            style={[styles.sendBtn, input.trim() ? styles.sendBtnActive : styles.sendBtnInactive]}>
            <Text style={styles.sendBtnText}>Send</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

export default function MessagesScreen() {
  const [conversations] = useState<Conversation[]>(SAMPLE_CONVERSATIONS);
  const [activeDM, setActiveDM] = useState<Conversation | null>(null);

  if (activeDM) {
    return <DMScreen conversation={activeDM} onBack={() => setActiveDM(null)} />;
  }

  return <MessagesList conversations={conversations} onOpenDM={setActiveDM} />;
}

const PINK = '#E8476A';

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  keyboardView: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: '700',
    color: '#111111',
    letterSpacing: -0.5,
  },
  divider: {
    height: 1,
    backgroundColor: '#F3F4F6',
    marginHorizontal: 20,
    marginBottom: 4,
  },
  listContent: {
    paddingBottom: 24,
  },
  convoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  avatarWrapper: {
    position: 'relative',
    marginRight: 12,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 99,
  },
  onlineDot: {
    position: 'absolute',
    bottom: 1,
    right: 1,
    width: 13,
    height: 13,
    borderRadius: 99,
    backgroundColor: '#22C55E',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  convoText: {
    flex: 1,
  },
  convoTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 3,
  },
  convoName: {
    fontWeight: '600',
    fontSize: 15,
    color: '#111111',
  },
  convoTime: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  convoTimeUnread: {
    color: PINK,
    fontWeight: '500',
  },
  convoBottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  convoLastMsg: {
    flex: 1,
    fontSize: 13,
    color: '#9CA3AF',
  },
  convoLastMsgUnread: {
    color: '#1F2937',
    fontWeight: '500',
  },
  unreadBadge: {
    marginLeft: 8,
    width: 20,
    height: 20,
    borderRadius: 99,
    backgroundColor: PINK,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unreadBadgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  emptyIcon: {
    width: 80,
    height: 80,
    borderRadius: 99,
    backgroundColor: '#FCE7EB',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  emptyIconText: {
    fontSize: 24,
    fontWeight: '700',
    color: PINK,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1F2937',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 20,
  },
  dmHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  backBtn: {
    marginRight: 8,
    padding: 4,
  },
  backArrow: {
    fontSize: 24,
    color: PINK,
    lineHeight: 28,
  },
  dmIdentity: {
    flex: 1,
  },
  dmName: {
    fontWeight: '600',
    fontSize: 15,
    color: '#111111',
  },
  dmStatus: {
    fontSize: 12,
    color: '#22C55E',
  },
  heartBtn: {
    minWidth: 52,
    height: 36,
    borderRadius: 99,
    backgroundColor: '#FCE7EB',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  heartBtnText: {
    fontSize: 12,
    fontWeight: '700',
    color: PINK,
  },
  messageList: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 10,
  },
  msgRow: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  msgRowMe: {
    justifyContent: 'flex-end',
  },
  msgRowThem: {
    justifyContent: 'flex-start',
  },
  msgAvatar: {
    width: 28,
    height: 28,
    borderRadius: 99,
    marginRight: 8,
    alignSelf: 'flex-end',
    marginBottom: 4,
  },
  msgRight: {
    maxWidth: '72%',
    alignItems: 'flex-end',
  },
  msgLeft: {
    maxWidth: '72%',
    alignItems: 'flex-start',
  },
  bubble: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 18,
  },
  bubbleMe: {
    backgroundColor: PINK,
    borderBottomRightRadius: 4,
  },
  bubbleThem: {
    backgroundColor: '#F3F4F6',
    borderBottomLeftRadius: 4,
  },
  bubbleText: {
    fontSize: 14,
    color: '#1F2937',
    lineHeight: 20,
  },
  bubbleTextMe: {
    color: '#FFFFFF',
  },
  msgTime: {
    fontSize: 10,
    color: '#9CA3AF',
    marginTop: 3,
    marginHorizontal: 4,
  },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
    gap: 8,
  },
  textInput: {
    flex: 1,
    minHeight: 42,
    maxHeight: 96,
    backgroundColor: '#F3F4F6',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 14,
    color: '#1F2937',
  },
  sendBtn: {
    minWidth: 56,
    height: 40,
    borderRadius: 99,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  sendBtnActive: {
    backgroundColor: PINK,
  },
  sendBtnInactive: {
    backgroundColor: '#E5E7EB',
  },
  sendBtnText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '700',
  },
});
