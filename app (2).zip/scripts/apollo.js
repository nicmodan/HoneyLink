import { ApolloClient, InMemoryCache, createHttpLink } from "@apollo/client";
import { setContext } from "@apollo/client/link/context";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Preferred: set EXPO_PUBLIC_GRAPHQL_URL so you can change the backend URL without editing code.
// This fallback points to your current Wi-Fi LAN IP and backend port for testing on a phone.
const GRAPHQL_URL =
  process.env.EXPO_PUBLIC_GRAPHQL_URL || "https://hony-link-backend.onrender.com/graphql";

// Easy fallback options if you need to switch later:
// const GRAPHQL_URL = "http://localhost:4000/graphql";
// const GRAPHQL_URL = "http://10.15.63.215:4000/graphql";
const httpLink = createHttpLink({
  uri: GRAPHQL_URL,
});

const authLink = setContext(async (_, { headers }) => {
  const token = await AsyncStorage.getItem("token");

  return {
    headers: {
      ...headers,
      authorization: token ? `Bearer ${token}` : "",
    },
  };
});

const client = new ApolloClient({
  link: authLink.concat(httpLink),
  cache: new InMemoryCache(),
});

export default client;
