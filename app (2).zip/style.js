import { Platform, StatusBar, StyleSheet } from "react-native";

const styles =  StyleSheet.create({
  
  // NOTE!!!: Group 1 Places your styles here
  background: {
    flex: 1,
    justifyContent: "center",
  },
  overlay: {
    ...StyleSheet.absoluteFill,
    backgroundColor: "rgba(223, 51, 110, 0.34)",
  },

  content: {
    flex: 1,
    justifyContent: "flex-end",
    paddingHorizontal: 24,
    paddingBottom: 72,
    paddingTop: Platform.select({
      ios: 48,
      android: (StatusBar.currentHeight ?? 0) + 24,
      default: 24,
    }),
  },
  displayText: {
    maxWidth: 240,
    marginBottom: 28,
    fontSize: 42,
    fontWeight: "800",
    lineHeight: 46,
    color: "#FFFFFF",
  },

  primaryButton: {
    alignItems: "center",
    justifyContent: "center",
    minHeight: 52,
    marginBottom: 14,
    borderRadius: 999,
    backgroundColor: "#ff2b78",
  },

  primaryButtonText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#FFFFFF",
  },

  secondaryButton: {
    alignItems: "center",
    justifyContent: "center",
    minHeight: 52,
    borderRadius: 999,
    backgroundColor: "#FFFFFF",
  },

  secondaryButtonText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#3A3A3A",
  },
  
  // ------------------Group 1 styles End-------------------



  // NOTE!!!: Group 2 Places your styles here
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "stretch",
    justifyContent: "flex-start",
    paddingTop: Platform.OS === "android" ? 40 : 50,
    paddingHorizontal: 25,
  },

  // Header Section Styles - by DARE
  headerContainer: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    paddingTop: 10,
    width: '100%',
  },

  headerContainer2: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '58%',
  },

  backButton: {
    marginBottom: 8,
    left: -4,
  },

  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: '#111',
    marginBottom: 10,
  },

  welcomeText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 25,
  },

  subText: {
    fontSize: 14,
    color: '#666',
    marginTop: 13,
  },
  
  // Email Password Login Section Styles - Micah
  formContainer: {
    width: '100%',
    marginTop: 40,
    gap: 20,
  },

  inputContainer: {
    height: 48,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    justifyContent: 'center',
  },

  passwordRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  input: {
    fontSize: 16,
    color: '#1F2937',
    flex: 1,
  },

  forgotButton: {
    alignSelf: 'flex-start',
    marginTop: -2,
    marginBottom: 16,
    left: 3,
  },

  forgotText: {
    color: '#ff2b78',
    fontSize: 14,
    fontWeight: '600',
  },

  // Social Login Section Styles - by Ifunanya
  socialLoginContainer: {
    width: '100%',
    paddingVertical: 16,
    gap: 28,
  },

  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },

  divider: {
    flex: 1,
    height: 1,
    backgroundColor: '#D1D5DB',
  },

  dividerLabel: {
    fontSize: 15,
    color: '#6B7280',
  },

  socialButton: {
    height: 48,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: -10,
  },

  facebook: {
    backgroundColor: '#3b5998',
  },

  gmail: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    backgroundColor: '#fff',
  },

  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },

  facebookContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },

  facebookIcon: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '800',
  },

  gmailText: {
    color: '#1F2937',
    fontSize: 16,
    fontWeight: '600',
  },

  termsText: {
    marginTop: 70,
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
  },

  loginButton: {
    height: 48,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ff2b78',
  },

  loginButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },

  // ------------------Group 2 styles End-------------------


  // NOTE!!!: Group 3 has been refactored for clarity and responsiveness.
  // These styles are intended for the SignUp screen.
  signUpContainer: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 24,
  },

  // Use SafeAreaView for top/bottom padding in your component
  // e.g., <SafeAreaView style={styles.signUpContainer} edges={['top', 'bottom']}>

  signUpHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 16, // Adjust as needed
    marginBottom: 24,
  },

  signUpBackArrow: {
    padding: 8,
    marginLeft: -8,
  },

  signUpTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 8,
  },

  signUpSubtitle: {
    fontSize: 16,
    color: 'gray',
    marginBottom: 32,
  },

  signUpForm: {
    width: '100%',
    gap: 20,
  },

  signUpInput: {
    height: 48,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    justifyContent: 'center',
    color: '#aaa'
  },

  signUpPasswordContainer: {
    position: 'relative',
    width: '100%',
    justifyContent: 'center',
  },

  signUpPasswordInput: {
    paddingRight: 48,
  },

  signUpPasswordToggle: {
    position: 'absolute',
    right: 16,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
  },

  signUpButton: {
    height: 48,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ff2b78',
    marginTop: 24,
  },

  signUpButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },

  signUpTermsContainer: {
    marginTop: 24,
    paddingHorizontal: 16,
  },

  signUpTermsText: {
    fontSize: 14,
    color: 'gray',
    textAlign: 'center',
    lineHeight: 20,
  },

  signUpTermsLink: {
    color: '#ff2b78',
    fontWeight: 'bold',
  },

  // Place the footer outside the ScrollView for it to stick to the bottom
  signUpFooter: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20, // Space from bottom and content
  },

  signUpFooterText: {
    color: 'gray',
    fontSize: 14,
  },

  signUpFooterLink: {
    color: '#ea147c',
    fontWeight: 'bold',
    fontSize: 14,
    marginLeft: 4,
  },

  headerTitle2: {
    fontSize: 17,
    fontWeight: '600',
    color: '#111',
    marginLeft: 85,
  },

  navigationContainer:{
    position: "absolute",
    bottom: 0,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    left: 0,
    right: 0,
    height: 66,
    backgroundColor: "#fff",
    borderTopWidth: 0.5,
    borderColor: "#ddd",
    paddingHorizontal: 40,
  },
  fab: {
    position: "absolute",
    left: "50%",
    marginLeft: -30,
    backgroundColor: "#FF4D6D",
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    zIndex: 2,
  },

  profileScreen: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },

  profileHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingTop: Platform.OS === "android" ? 14 : 6,
    paddingBottom: 12,
  },

  profileHeaderButton: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },

  profileHeaderTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
  },

  profileEditButton: {
    minWidth: 36,
    alignItems: "flex-end",
    justifyContent: "center",
  },

  profileEditText: {
    fontSize: 15,
    fontWeight: "600",
    color: "#111827",
  },

  profileContent: {
    paddingHorizontal: 24,
    paddingTop: 8,
    paddingBottom: 130,
  },

  profileAvatarSection: {
    alignItems: "center",
    marginBottom: 26,
  },

  profileAvatar: {
    width: 92,
    height: 92,
    borderRadius: 46,
    marginBottom: 14,
  },

  profileName: {
    fontSize: 22,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 6,
  },

  profileLocation: {
    fontSize: 14,
    color: "#9CA3AF",
  },

  profileStatsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 30,
    paddingHorizontal: 10,
  },

  profileStatBlock: {
    alignItems: "center",
    flex: 1,
  },

  profileStatValue: {
    fontSize: 20,
    fontWeight: "700",
    color: "#FF4D6D",
    marginBottom: 4,
  },

  profileStatLabel: {
    fontSize: 13,
    color: "#6B7280",
  },

  profileTabsRow: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 32,
    marginBottom: 22,
  },

  profileTabButton: {
    alignItems: "center",
    minWidth: 70,
  },

  profileTabText: {
    fontSize: 15,
    fontWeight: "500",
    color: "#9CA3AF",
  },

  profileTabTextActive: {
    color: "#111827",
    fontWeight: "700",
  },

  profileTabUnderline: {
    marginTop: 8,
    width: 34,
    height: 3,
    borderRadius: 999,
    backgroundColor: "#FF4D6D",
  },

  profileAboutCard: {
    backgroundColor: "#FFF5F8",
    borderRadius: 22,
    padding: 20,
  },

  profileAboutTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 10,
  },

  profileAboutText: {
    fontSize: 14,
    lineHeight: 22,
    color: "#4B5563",
  },

  profileGalleryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    rowGap: 12,
  },

  profileGalleryImage: {
    width: "31%",
    aspectRatio: 1,
    borderRadius: 16,
  },

  profileDetailsScreen: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },

  profileDetailsHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 24,
    paddingTop: Platform.OS === "android" ? (StatusBar.currentHeight ?? 0) + 6 : 10,
    paddingBottom: 10,
  },

  profileDetailsHeaderButton: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },

  profileDetailsHeaderTitle: {
    fontSize: 17,
    fontWeight: "600",
    color: "#111827",
  },

  profileDetailsSaveButton: {
    minWidth: 40,
    alignItems: "flex-end",
    justifyContent: "center",
  },

  profileDetailsSaveText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FF4D6D",
  },

  profileDetailsContent: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 90,
  },

  profileDetailsAvatarWrap: {
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 24,
  },

  profileDetailsAvatarFrame: {
    position: "relative",
    width: 96,
    height: 96,
    alignItems: "center",
    justifyContent: "center",
  },

  profileDetailsAvatar: {
    width: 94,
    height: 94,
    borderRadius: 47,
  },

  profileDetailsCameraButton: {
    position: "absolute",
    right: -4,
    bottom: 8,
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: "#FF4D6D",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: "#FFFFFF",
  },

  profileDetailsFields: {
    gap: 0,
  },

  profileDetailsFieldCard: {
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
    paddingTop: 12,
    paddingBottom: 20,
  },

  profileDetailsFieldLabel: {
    fontSize: 13,
    color: "#9CA3AF",
    marginBottom: 10,
  },

  profileDetailsFieldValue: {
    fontSize: 16,
    fontWeight: "600",
    color: "#111827",
  },

  profileDetailsFieldInput: {
    fontSize: 16,
    fontWeight: "500",
    color: "#111827",
    paddingVertical: 0,
    minHeight: 24,
  },

  defaultProfileScreen: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: Platform.OS === "android" ? 40 : 50,
  },

  defaultProfileHeaderContainer: {
    backgroundColor: "#fff",
    paddingTop: 10,
    paddingBottom: 20,
    alignItems: "center",
  },

  defaultProfileHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    paddingHorizontal: 20,
    marginBottom: 20,
  },

  defaultProfileBackButton: {
    marginLeft: -20,
  },

  defaultProfileTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#333",
    left: 10,
  },

  defaultProfileEditButton: {
    fontSize: 16,
    color: "#888",
    left: 10,
  },

  defaultProfileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },

  defaultProfileName: {
    fontSize: 18,
    fontWeight: "600",
    color: "#333",
  },

  defaultProfileLocation: {
    fontSize: 14,
    color: "#666",
    marginTop: 5,
  },

  defaultProfileStatsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
    gap: 40,
  },

  defaultProfileStat: {
    alignItems: "center",
  },

  defaultProfileStatNumber: {
    color: "#ff4d6d",
    fontSize: 18,
    fontWeight: "600",
  },

  defaultProfileStatLabel: {
    color: "#666",
  },

  defaultProfileContent: {
    flex: 1,
    minHeight: 0,
  },

  defaultProfileTabRow: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 28,
    paddingTop: 8,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },

  defaultProfileTabButton: {
    alignItems: "center",
    minWidth: 72,
  },

  defaultProfileTabText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#999",
  },

  defaultProfileTabTextActive: {
    color: "#333",
  },

  defaultProfileTabIndicator: {
    marginTop: 8,
    height: 3,
    width: 65,
    borderRadius: 20,
    backgroundColor: "#ff2b78",
  },

  defaultProfileAbout: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
  },

  defaultProfileAboutText: {
    fontSize: 15,
    color: "#666",
    textAlign: "center",
    lineHeight: 22,
  },

  defaultProfileGalleryWrapper: {
    flex: 1,
    backgroundColor: "#fff",
    justifyContent: "flex-start",
    alignItems: "center",
  },

  defaultProfileInner: {
    flex: 1,
    width: "100%",
    backgroundColor: "#fff",
    alignSelf: "center",
    borderRadius: 18,
    overflow: "hidden",
  },

  defaultProfileGalleryList: {
    flex: 1,
  },

  defaultProfileGrid: {
    paddingHorizontal: 5,
    paddingTop: 14,
    paddingBottom: 120,
  },

  defaultProfileTile: {
    width: "30.5%",
    aspectRatio: 0.95,
    borderRadius: 14,
    overflow: "hidden",
    margin: 5,
  },

  defaultProfileTileImage: {
    width: "100%",
    height: "100%",
  },

  defaultProfileViewerContainer: {
    flex: 1,
    backgroundColor: "#000",
  },

  defaultProfileViewerSlide: {
    width: 360,
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
  },

  defaultProfileViewerImage: {
    width: 360,
    height: "100%",
  },

  defaultProfileCloseBtn: {
    position: "absolute",
    top: 48,
    right: 20,
    zIndex: 10,
    backgroundColor: "rgba(0,0,0,0.5)",
    borderRadius: 20,
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },

  defaultProfileCloseText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },

  // Popup / Modal styles (used in LoginUI)
  popupOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.45)",
    alignItems: "center",
    justifyContent: "center",
  },

  popupCard: {
    width: "82%",
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 28,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
    elevation: 10,
  },

  popupTitle: {
    fontSize: 20,
    fontWeight: "700",
    marginBottom: 10,
    textAlign: "center",
  },

  popupTitleSuccess: {
    color: "#22C55E",
  },

  popupTitleError: {
    color: "#EF4444",
  },

  popupMessage: {
    fontSize: 14,
    color: "#4B5563",
    textAlign: "center",
    lineHeight: 20,
    marginBottom: 20,
  },

  popupButton: {
    width: "100%",
    height: 46,
    borderRadius: 23,
    alignItems: "center",
    justifyContent: "center",
  },

  popupButtonSuccess: {
    backgroundColor: "#ff2b78",
  },

  popupButtonError: {
    backgroundColor: "#EF4444",
  },

  popupButtonText: {
    color: "#fff",
    fontSize: 15,
    fontWeight: "700",
  },
})

export default styles;
