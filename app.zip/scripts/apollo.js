import { setContext } from "@apollo/client/link/context";
import { onError } from "@apollo/client/link/error";
import {
  ApolloClient,
  InMemoryCache,
  createHttpLink,
  from,
} from "@apollo/client";
import { getToken } from "./auth";

const GRAPHQL_URL =
  process.env.EXPO_PUBLIC_GRAPHQL_URL ||
  "https://hony-link-backend-w44u.onrender.com/graphql";

console.log("[Apollo] Initializing with GraphQL URL:", GRAPHQL_URL);

const customFetch = async (uri, options = {}) => {
  const requestId = Math.random().toString(36).slice(2, 8);
  const startTime = Date.now();

  try {
    const controller = new AbortController();

    const timeoutId = setTimeout(() => {
      console.error(`[Apollo] Request #${requestId} TIMEOUT after 30s`);
      controller.abort();
    }, 30000);


    const response = await fetch(uri, {
      ...options,
      signal: controller.signal,
    });
    console.log("uri_fav", options);
    console.log("uri_fav_two", response);
    console.log("uri_fav_three", await response.clone().text());


    clearTimeout(timeoutId);

    const elapsed = Date.now() - startTime;

    console.log(
      `[Apollo] HTTP Response #${requestId} SUCCESS (${elapsed}ms):`,
      {
        status: response.status,
        statusText: response.statusText,
        contentLength: response.headers.get("content-length"),
        timestamp: new Date().toISOString(),
      }
    );

    return response;
  } catch (err) {
    const elapsed = Date.now() - startTime;

    console.error(
      `[Apollo] HTTP Request #${requestId} FAILED (${elapsed}ms):`,
      {
        message: err?.message,
        name: err?.name,
        code: err?.code,
        timestamp: new Date().toISOString(),
      }
    );

    throw err;
  }
};

const httpLink = createHttpLink({
  uri: GRAPHQL_URL,
  fetch: customFetch,
});

const authLink = setContext(async (_, { headers }) => {
  const token = await getToken();

  console.log("[Apollo] AuthLink: Token exists?", !!token);

  return {
    headers: {
      ...headers,
      authorization: token ? `Bearer ${token}` : "",
    },
  };
});

const errorLink = onError(({ graphQLErrors, networkError, operation }) => {
  console.log("[Apollo] Error in operation:", operation.operationName);

  if (graphQLErrors) {
    graphQLErrors.forEach(({ message, path }) => {
      console.warn(`[GraphQL error]: ${message}, Path: ${path}`);
    });
  }

  if (networkError) {
    console.warn("[Network error]:", networkError);
  }
});

const client = new ApolloClient({
  link: from([errorLink, authLink, httpLink]),
  cache: new InMemoryCache(),
});

export default client;